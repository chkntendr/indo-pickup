<p align="center"><a href="https://indonusa-express.id" target="_blank"><img src="https://github.com/chkntendr/pickup-to-invoice/public/assets/img/logo-2.png" width="400" alt="Indonusa Express"></a></p>

## Indonusa Express

Inventory Sistem

## Fitur
 - Input data pickup dari administrasi sampai ke bagian penagihan
 - Reporting untuk bagian penagihan
